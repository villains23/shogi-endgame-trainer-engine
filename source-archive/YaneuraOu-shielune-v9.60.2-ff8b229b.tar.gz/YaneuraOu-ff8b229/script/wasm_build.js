#!/usr/bin/env node
const { exec, execSync } = require("child_process");
const fpath = require("path");
const fs = require("fs");
const os = require("os");
const process = require("process");
const zlib = require("zlib");

const arch = execSync('uname -m').toString().trim();
const version = execSync('em++ --version').toString().match(/(\d+\.\d+\.\d+)/)[1]
const pkgobjs = [
  {
    name: "halfkp256",
    edition: "YANEURAOU_ENGINE_NNUE",
    exportname: "YaneuraOu_HalfKP256",
    extra: "ENGINE_NAME=Suisho5+YaneuraOu EVAL_EMBEDDING=ON EM_INITIAL_MEMORY_SIZE=167772160 EXTRA_CPPFLAGS='-DENGINE_OPTIONS=\\\"\"option=name=FV_SCALE=type=spin=default=24=min=1=max=128\\\"\"'",
    evalfile: true,
  },
  {
    name: "halfkp768.noeval",
    edition: "YANEURAOU_ENGINE_NNUE_HALFKP_768X2_16_64",
    exportname: "YaneuraOu_HalfKP768_noeval",
    extra: "EM_INITIAL_MEMORY_SIZE=268435456",
    evalfile: true,
  },
  {
    name: "k-p",
    edition: "YANEURAOU_ENGINE_NNUE_KP256",
    exportname: "YaneuraOu_K_P",
    extra: "EVAL_EMBEDDING=ON EM_INITIAL_MEMORY_SIZE=92274688 EXTRA_CPPFLAGS='-DENGINE_OPTIONS=\\\"\"option=name=FV_SCALE=type=spin=default=24=min=1=max=128\\\"\"'",
    evalfile: true,
  },
  {
    name: "halfkp256.noeval",
    edition: "YANEURAOU_ENGINE_NNUE",
    exportname: "YaneuraOu_HalfKP256_noeval",
    extra: "EM_INITIAL_MEMORY_SIZE=167772160",
    evalfile: true,
  },
  {
    name: "halfkpe9.noeval",
    edition: "YANEURAOU_ENGINE_NNUE_HALFKPE9",
    exportname: "YaneuraOu_HalfKPE9_noeval",
    extra: "EM_INITIAL_MEMORY_SIZE=167772160",
    evalfile: true,
  },
  {
    name: "halfkpvm.noeval",
    edition: "YANEURAOU_ENGINE_NNUE_HALFKP_VM_256X2_32_32",
    exportname: "YaneuraOu_HalfKPvm_noeval",
    extra: "EM_INITIAL_MEMORY_SIZE=167772160",
    evalfile: true,
  },
  {
    name: "k-p.noeval",
    edition: "YANEURAOU_ENGINE_NNUE_KP256",
    exportname: "YaneuraOu_K_P_noeval",
    extra: "EM_INITIAL_MEMORY_SIZE=92274688",
    evalfile: true,
  },
  {
    name: "material",
    edition: "YANEURAOU_ENGINE_MATERIAL",
    exportname: "YaneuraOu_Material",
    extra: "MATERIAL_LEVEL=1 EM_INITIAL_MEMORY_SIZE=92274688",
    evalfile: false,
  },
  {
    name: "material9",
    edition: "YANEURAOU_ENGINE_MATERIAL",
    exportname: "YaneuraOu_Material9",
    extra: "MATERIAL_LEVEL=9 EM_INITIAL_MEMORY_SIZE=402653184",
    evalfile: false,
  },
  {
    name: "mobility",
    // KIKI edition embeds the 164-dim learned linear weights via
    // source/eval/kiki/mobility_weights_embedded.cpp — no external nn.bin.
    edition: "YANEURAOU_ENGINE_KIKI",
    exportname: "YaneuraOu_Mobility",
    extra: "EM_INITIAL_MEMORY_SIZE=92274688",
    evalfile: false,
  },
  {
    name: "yaneuraou-mate",
    edition: "YANEURAOU_MATE_ENGINE",
    exportname: "YaneuraOu_MATE",
    extra: "EM_INITIAL_MEMORY_SIZE=92274688",
    evalfile: false,
  },
  {
    name: "tanuki-mate",
    edition: "TANUKI_MATE_ENGINE",
    exportname: "tanuki_MATE",
    extra: "EM_INITIAL_MEMORY_SIZE=92274688",
    evalfile: false,
  },
];

const args = process.argv.slice(2);
const pkglist = args.length ? pkgobjs.filter((e) => (args.indexOf(e.name) >= 0)) : pkgobjs;

if(!fs.existsSync("source/Makefile")) {
  console.error("source folder not found");
  process.exit(1);
}

const cwd = process.cwd();
const cpus = os.cpus().length;

// ── Patch management ──
// patches/*.patch are applied to the working tree right before `make` runs
// and reverted on exit (success or failure) so the repo stays clean for the
// next invocation. Re-applying an already-applied patch is a no-op thanks to
// the `git apply --reverse --check` probe.
const patchesDir = fpath.join(cwd, "patches");
const patchFiles = fs.existsSync(patchesDir)
  ? fs.readdirSync(patchesDir).filter((f) => f.endsWith(".patch")).sort()
  : [];

function patchApplied(p) {
  try {
    execSync(`git apply --reverse --check "patches/${p}"`, { cwd, stdio: "pipe" });
    return true;
  } catch {
    return false;
  }
}

function applyPatches() {
  for (const p of patchFiles) {
    if (patchApplied(p)) {
      console.log(`[patch] ${p} already applied — skip`);
      continue;
    }
    console.log(`[patch] applying ${p}`);
    execSync(`git apply "patches/${p}"`, { cwd, stdio: "inherit" });
  }
}

function revertPatches() {
  for (const p of [...patchFiles].reverse()) {
    if (!patchApplied(p)) continue;
    try {
      execSync(`git apply --reverse "patches/${p}"`, { cwd, stdio: "inherit" });
      console.log(`[patch] reverted ${p}`);
    } catch (e) {
      console.warn(`[patch] failed to revert ${p}: ${e.message}`);
    }
  }
}

let patchesReverted = false;
function revertOnce() {
  if (patchesReverted) return;
  patchesReverted = true;
  revertPatches();
}
process.on("exit", revertOnce);
process.on("SIGINT", () => process.exit(130));
process.on("SIGTERM", () => process.exit(143));

// Three build variants are produced from the same source per package, so
// downstream runners can test each target:
//   - web  : ENVIRONMENT=web,worker,        pthread=on  EXPORTED_RUNTIME_METHODS=['FS','ccall']
//            → drives Playwright + Chromium in script/wasm_eval_browser.ts
//   - node : ENVIRONMENT=node,              pthread=on  EXPORTED_RUNTIME_METHODS=['FS','ccall','callMain']
//            → drives node:worker_threads in script/wasm_eval_node.ts
//   - edge : ENVIRONMENT=web,               pthread=off EXPORTED_RUNTIME_METHODS=['FS','ccall']
//            → single-thread build for V8 Isolate runtimes (Cloudflare
//              Workers / Vercel Edge / Deno Deploy), where Worker and
//              SharedArrayBuffer are not available.
// callMain is only needed on the node variant because the node loader
// uses noInitialRun:true and triggers main() explicitly (see
// script/loaders/node/common.ts and docs/wasm_client_usage.md).
const allVariants = [
  {
    name: "web",
    em_environment: "web,worker",
    em_exported_runtime_methods: "['FS','ccall']",
    em_pthread: 1,
  },
  {
    name: "node",
    em_environment: "node",
    em_exported_runtime_methods: "['FS','ccall','callMain']",
    em_pthread: 1,
  },
  {
    name: "edge",
    em_environment: "web",
    em_exported_runtime_methods: "['FS','ccall']",
    em_pthread: 0,
  },
];
// Optional filter: `VARIANT=edge node script/wasm_build.js k-p` builds only
// the edge variant. Useful for iterating on a single target without redoing
// the full sweep.
const variantFilter = process.env.VARIANT
  ? process.env.VARIANT.split(",").map((s) => s.trim())
  : null;
const variants = variantFilter
  ? allVariants.filter((v) => variantFilter.includes(v.name))
  : allVariants;
if (variants.length === 0) {
  console.error(
    `[wasm_build] VARIANT filter '${process.env.VARIANT}' matched no variants. ` +
      `Known: ${allVariants.map((v) => v.name).join(", ")}`,
  );
  process.exit(1);
}

(async () => {
try {
  applyPatches();
for(const pkgobj of pkglist) {
  // embedded_nnue setup (shared between variants — only touches
  // source/eval/nnue/embedded_nnue.cpp which is the same for both builds)
  switch(pkgobj.name) {
    case "halfkp256":
      if (!fs.existsSync(".dl/suisho5_20211123.halfkp.nnue.cpp.gz")) {
        execSync("curl --create-dirs -RLo .dl/suisho5_20211123.halfkp.nnue.cpp.gz https://github.com/mizar/YaneuraOu/releases/download/resource/suisho5_20211123.halfkp.nnue.cpp.gz");
      }
      execSync("gzip -cd .dl/suisho5_20211123.halfkp.nnue.cpp.gz > source/eval/nnue/embedded_nnue.cpp");
      break;
    case "k-p":
      if(!fs.existsSync(".dl/suishopetite_20211123.k_p.nnue.cpp.gz")) {
        execSync("curl --create-dirs -RLo .dl/suishopetite_20211123.k_p.nnue.cpp.gz https://github.com/mizar/YaneuraOu/releases/download/resource/suishopetite_20211123.k_p.nnue.cpp.gz");
      }
      execSync("gzip -cd .dl/suishopetite_20211123.k_p.nnue.cpp.gz > source/eval/nnue/embedded_nnue.cpp");
      break;
  }

for(const variant of variants) {
  const builddirusi = `build/${version}_${arch}/${pkgobj.name}/${variant.name}/`;
  const builddirlib = `build/${version}_${arch}/${pkgobj.name}/${variant.name}/lib/`;
  const usijs_copy_dirs = [
  ];
  const dts_copy_dirs = [
  ];
  const lib_copy_dirs = [
  ];
  // mkdir
  fs.mkdirSync(fpath.join(cwd, builddirlib), { recursive: true });
  for (const copy_dir of lib_copy_dirs) {
    fs.mkdirSync(fpath.join(cwd, copy_dir), { recursive: true });
  }
  // rm
  for(const libfile of fs.readdirSync(builddirlib)) {
    fs.rmSync(fpath.join(builddirlib, libfile), { force: true });
  }
  // usi.js
  const bpath_usijs = fpath.join(cwd, builddirusi, `usi.${pkgobj.name}.js`);
  const bpath_usits = fpath.join(cwd, builddirusi, `usi.${pkgobj.name}.ts`);
  fs.writeFileSync(bpath_usijs, `#!/usr/bin/env node
const process = require("process");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const YaneuraOu = require("./lib/yaneuraou.${pkgobj.name}");

const USI_BOOK_FILE = process.env.USI_BOOK_FILE;
const USI_EVAL_FILE = process.env.USI_EVAL_FILE;

async function runRepl(yaneuraou) {
  const iface = readline.createInterface({ input: process.stdin });
  for await (const command of iface) {
    if (command == "quit") {
      break;
    }
    yaneuraou.postMessage(command);
  }
  yaneuraou.terminate();
}

async function main(argv) {
  const wasmBinary = await fs.promises.readFile(path.join(__dirname, "./lib/yaneuraou.${pkgobj.name}.wasm"));
  const yaneuraou = await YaneuraOu({ wasmBinary });
  const FS = yaneuraou.FS;
  if (USI_BOOK_FILE) {
    const buffer = await fs.promises.readFile(USI_BOOK_FILE);
    FS.writeFile(\`/\${path.basename(USI_BOOK_FILE)}\`, buffer);
    yaneuraou.postMessage("setoption name BookDir value .");
    yaneuraou.postMessage(\`setoption name BookFile value \${path.basename(USI_BOOK_FILE)}\`);
  }
  const USE_EVAL_FILE = ${pkgobj.evalfile};
  if (USE_EVAL_FILE && USI_EVAL_FILE) {
    const buffer = await fs.promises.readFile(USI_EVAL_FILE);
    const filebase = path.basename(USI_EVAL_FILE);
    FS.writeFile(\`/\${filebase}\`, buffer);
    yaneuraou.postMessage("setoption name EvalDir value .");
    yaneuraou.postMessage(\`setoption name EvalFile value \${filebase}\`);
  }
  if (argv.length > 0) {
    const commands = argv.join(" ").split(" , ");
    for (const command of commands) {
      yaneuraou.postMessage(command);
    }
    yaneuraou.terminate();
    return;
  }
  runRepl(yaneuraou);
}

if (require.main === module) {
  main(process.argv.slice(2));
}
`);
  fs.writeFileSync(bpath_usits, `/// <reference types="emscripten" />
import process from "process";
import fs from "fs";
import path from "path";
import readline from "readline";
import YaneuraOu = require("./lib/yaneuraou.${pkgobj.name}");
import { YaneuraOuModule } from "./lib/yaneuraou.module";

const USI_BOOK_FILE = process.env.USI_BOOK_FILE;
const USI_EVAL_FILE = process.env.USI_EVAL_FILE;

async function runRepl(yaneuraou: YaneuraOuModule) {
  const iface = readline.createInterface({ input: process.stdin });
  for await (const command of iface) {
    if (command == "quit") {
      break;
    }
    yaneuraou.postMessage(command);
  }
  yaneuraou.terminate();
}

async function main(argv: string[]) {
  const wasmBinary = await fs.promises.readFile(path.join(__dirname, "./lib/yaneuraou.${pkgobj.name}.wasm"));
  const yaneuraou: YaneuraOuModule = await YaneuraOu({ wasmBinary });
  const FS = yaneuraou.FS;
  if (USI_BOOK_FILE) {
    const buffer = await fs.promises.readFile(USI_BOOK_FILE);
    FS.writeFile(\`/\${path.basename(USI_BOOK_FILE)}\`, buffer);
    yaneuraou.postMessage("setoption name BookDir value .");
    yaneuraou.postMessage(\`setoption name BookFile value \${path.basename(USI_BOOK_FILE)}\`);
  }
  const USE_EVAL_FILE = ${pkgobj.evalfile};
  if (USE_EVAL_FILE && USI_EVAL_FILE) {
    const buffer = await fs.promises.readFile(USI_EVAL_FILE);
    const filebase = path.basename(USI_EVAL_FILE);
    FS.writeFile(\`/\${filebase}\`, buffer);
    yaneuraou.postMessage("setoption name EvalDir value .");
    yaneuraou.postMessage(\`setoption name EvalFile value \${filebase}\`);
  }
  if (argv.length > 0) {
    const commands = argv.join(" ").split(" , ");
    for (const command of commands) {
      yaneuraou.postMessage(command);
    }
    yaneuraou.terminate();
    return;
  }
  runRepl(yaneuraou);
}

if (require.main === module) {
  main(process.argv.slice(2));
}
`);
  for(const copy_dir of usijs_copy_dirs) {
    fs.copyFileSync(bpath_usijs, fpath.join(cwd, copy_dir, `usi.${pkgobj.name}.js`));
    fs.copyFileSync(bpath_usits, fpath.join(cwd, copy_dir, `usi.${pkgobj.name}.ts`));
  }
  // .d.ts
  const bpath_dts = fpath.join(cwd, builddirlib, `yaneuraou.${pkgobj.name}.d.ts`);
  const bpath_module_dts = fpath.join(cwd, builddirlib, `yaneuraou.module.d.ts`);
  fs.writeFileSync(bpath_module_dts, `/// <reference types="emscripten" />

export interface YaneuraOuModule extends EmscriptenModule
{
  addMessageListener: (listener: (line: string) => void) => void;
  removeMessageListener: (listener: (line: string) => void) => void;
  postMessage: (command: string) => void;
  terminate: () => void;
  ccall: typeof ccall;
  FS: typeof FS;
}
`);
  fs.writeFileSync(bpath_dts, `/// <reference types="emscripten" />
import { YaneuraOuModule } from "./yaneuraou.module";

declare const ${pkgobj.exportname}: EmscriptenModuleFactory<YaneuraOuModule>;
export = ${pkgobj.exportname};
`);
  for(const copy_dir of dts_copy_dirs) {
    fs.copyFileSync(bpath_module_dts, fpath.join(cwd, copy_dir, `yaneuraou.module.d.ts`));
    fs.copyFileSync(bpath_dts, fpath.join(cwd, copy_dir, `yaneuraou.${pkgobj.name}.d.ts`));
  }
  // make — parameterised per variant via EM_ENVIRONMENT /
  // EM_EXPORTED_RUNTIME_METHODS (source/Makefile reads both as `?=`
  // variables in the em++ branch). pkgobj.extra contains shell-quoted
  // segments (`EXTRA_CPPFLAGS='-DENGINE_OPTIONS="…"'`) so we keep it as a
  // single shell command string and let the shell parse the quoting.
  // execSync with stdio:"inherit" forwards make's stdout/stderr to this
  // process directly so `docker run` callers see the full build log.
  console.log(`[wasm_build] starting ${variant.name} build for ${pkgobj.name} (${version}_${arch})`);
  const cmd = `make -j${cpus} clean tournament COMPILER=em++ TARGET_CPU=WASM YANEURAOU_EDITION=${pkgobj.edition} TARGET=../${builddirlib}yaneuraou.${pkgobj.name}.js EM_EXPORT_NAME=${pkgobj.exportname} EM_ENVIRONMENT=${variant.em_environment} EM_EXPORTED_RUNTIME_METHODS="${variant.em_exported_runtime_methods}" EM_PTHREAD=${variant.em_pthread} ${pkgobj.extra} -s EXPORT_ES6=1 -s MODULARIZE=1`;
  try {
    execSync(cmd, {
      cwd: fpath.join(cwd, "source"),
      stdio: "inherit",
    });
  } catch (err) {
    console.error(`[wasm_build] make failed for ${variant.name}: ${err.message}`);
    process.exit(1);
  }
  console.log(`[wasm_build] finished ${variant.name} build for ${pkgobj.name}`);
  // compress, public copy
  for (const fext of ["js", "worker.js", "wasm"]) {
    const bfile = `yaneuraou.${pkgobj.name}.${fext}`;
    const bfile_br = `yaneuraou.${pkgobj.name}.${fext}.br`;
    const bfile_gz = `yaneuraou.${pkgobj.name}.${fext}.gz`;
    const bpath = fpath.join(cwd, builddirlib, bfile);
    const bpath_br = fpath.join(cwd, builddirlib, bfile_br);
    const bpath_gz = fpath.join(cwd, builddirlib, bfile_gz);
    const ws_br = fs.createWriteStream(bpath_br);
    const ws_gz = fs.createWriteStream(bpath_gz);
    if(!fs.existsSync(bpath)) {
      // Only the classic-worker generation (3.1.43) emits a separate
      // `.worker.js`. From 3.1.60 onwards the worker is inlined into
      // the main ES module and no sibling file is produced, so skip
      // compression silently instead of aborting the whole build.
      if (fext === "worker.js") {
        console.warn(`[wasm_build] no separate ${bfile} (inlined worker generation), skipping compress`);
        continue;
      }
      console.error(`file not found: ${bpath}`);
      process.exit(1);
    }
    for(const copy_dir of lib_copy_dirs) {
      fs.copyFileSync(bpath, fpath.join(cwd, copy_dir, bfile));
    }
    const { atime, mtime } = fs.statSync(bpath);
    ws_br.on('finish', () => {
      fs.utimesSync(bpath_br, atime, mtime);
      for(const copy_dir of lib_copy_dirs) {
        fs.copyFileSync(bpath_br, fpath.join(cwd, copy_dir, bfile_br));
        fs.utimesSync(fpath.join(cwd, copy_dir, bfile_br), atime, mtime);
      }
      console.log(`compress finished: ${bpath_br}`);
    });
    ws_gz.on('finish', () => {
      fs.utimesSync(bpath_gz, atime, mtime);
      for(const copy_dir of lib_copy_dirs) {
        fs.copyFileSync(bpath_gz, fpath.join(cwd, copy_dir, bfile_gz));
        fs.utimesSync(fpath.join(cwd, copy_dir, bfile_gz), atime, mtime);
      }
      console.log(`compress finished: ${bpath_gz}`);
    });
    // compress
    fs.createReadStream(bpath)
      .pipe(zlib.createBrotliCompress({
        params: {
          [zlib.constants.BROTLI_PARAM_QUALITY]: zlib.constants.BROTLI_MAX_QUALITY,
        }
      }))
      .pipe(ws_br);
    fs.createReadStream(bpath)
      .pipe(zlib.createGzip({
        level: zlib.constants.Z_MAX_LEVEL,
      }))
      .pipe(ws_gz);
  }
}  // variant loop
}  // pkgobj loop
} catch (err) {
  console.error("[wasm_build] failed:", err);
  process.exitCode = 1;
}
})();
